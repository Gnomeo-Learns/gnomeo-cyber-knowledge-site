# CS8833 Enterprise Cybersecurity Management — Module 3 Content Update

## Overview

This package adds missing content to the Module 3 (Security Assurance) section of the `gnomeo-cyber-knowledge-site` Astro site. It includes:

1. **Three entirely new topic pages** (T3, T4, T5)
2. **Expanded content for two existing topic pages** (T1, T2)  
3. **Updated Module 3 overview page** (adds cards for T3, T4, T5)
4. **New glossary entries** (~25 new terms)
5. **Sidebar navigation updates**

Also note: the correct course number is **CS 8833** (not CS8803). The site header and references should be updated.

---

## Files in This Package

| File | Purpose | Action |
|---|---|---|
| `t3-reporting-metrics.astro` | New Topic 3: GRC Reporting & Metrics (4 lessons) | Create as `src/pages/m3-assurance/t3-reporting-metrics.astro` |
| `t4-appsec.astro` | New Topic 4: Application Security (9 lessons) | Create as `src/pages/m3-assurance/t4-appsec.astro` |
| `t5-red-teaming.astro` | New Topic 5: Red Teaming (6 lessons) | Create as `src/pages/m3-assurance/t5-red-teaming.astro` |
| `t1-expansion-lessons3-8.astro` | Additional lessons for existing T1 (Risk Register) | Merge LessonCards into existing `src/pages/m3-assurance/t1-risk-register.astro` |
| `t2-expansion-lessons5-9.astro` | Additional lessons for existing T2 (Compliance & Policy) | Merge LessonCards into existing `src/pages/m3-assurance/t2-compliance-policy.astro` |
| `m3-overview-updated.astro` | Updated Module 3 overview with all 5 topic cards | Replace `src/pages/m3-assurance/index.astro` |
| `glossary-additions.txt` | ~25 new glossary term definitions | Add entries to existing glossary page |

---

## Step-by-Step Implementation

### 1. Fix Course Number

Search the entire codebase for "CS8803" and replace with "CS8833". Key locations:
- Site header / title
- Page titles and meta tags
- Footer references
- Any "Source Material" sections

Also update "CS6239" references to note it's a cross-listing: "CS8833 / CS6239"

### 2. Create New Topic Pages

Copy these files directly into `src/pages/m3-assurance/`:
- `t3-reporting-metrics.astro`
- `t4-appsec.astro`  
- `t5-red-teaming.astro`

Verify the import paths match the existing pattern. Check `t1-risk-register.astro` for the correct relative paths:
```astro
import BaseLayout from '../../layouts/BaseLayout.astro';
import LessonCard from '../../components/LessonCard.astro';
import Callout from '../../components/Callout.astro';
```

### 3. Expand Existing T1 (Risk Register)

Open `src/pages/m3-assurance/t1-risk-register.astro`.

The existing page has 4 LessonCards (lessons covering Purpose, Structure/Fields, Scoring, and IR Integration). The expansion file (`t1-expansion-lessons3-8.astro`) contains 6 new LessonCards.

**Important**: The existing site's lessons are numbered 1-4, and the new content uses lesson numbers 3-8 from the source material. You'll need to reconcile the numbering. The recommended approach:

- Keep existing lessons as-is (they cover the right content)
- Append the new LessonCards after the last existing one
- Adjust the `code=` attributes so numbering is sequential (Lesson 5, 6, 7, 8, 9, 10 — or whatever continues from the existing last lesson number)

The new lessons to add cover:
- SLAs (Service Level Agreements)
- Sources and Workflow (risk intake and triage process)
- Risk Register Fields (detailed field specifications)
- Urgency Scoring (likelihood × impact calculation)
- Reporting (remediation agility chart, governance reporting)
- RAMP Exercises (5 practical scoring exercises)

### 4. Expand Existing T2 (Compliance & Policy)

Open `src/pages/m3-assurance/t2-compliance-policy.astro`.

Same approach: the existing page has 4 LessonCards. Append the 5 new LessonCards from `t2-expansion-lessons5-9.astro` after the existing content. Adjust `code=` numbering to be sequential.

The new lessons cover:
- The Chain of TPRM (third-party risk management trust chain)
- Questionnaires (handling inbound security assessments)
- Policy Guiding Principles (practical rules for writing effective policy)
- Policy Components (13 security policies + non-security policies to know)
- Acceptable Use Policy Deep Dive (comprehensive AUP breakdown)

### 5. Update Module 3 Overview

Replace `src/pages/m3-assurance/index.astro` with `m3-overview-updated.astro`.

**Check the markup**: The existing overview page may use slightly different CSS classes or card markup than what I've provided. Compare against the current file and adjust the new topic cards (T3, T4, T5) to match the existing T1 and T2 card patterns exactly. The key things to match:
- Card link `href` paths (must include the base path `/gnomeo-cyber-knowledge-site/`)
- CSS class names for the card container, label, title, and description
- Any wrapper elements around the card grid

### 6. Update Sidebar Navigation

The sidebar is likely defined in a component (check `src/components/Sidebar.astro` or similar, or it may be in the layout). Add three new entries under "Module 03 — Assurance":

```
T3 · Reporting & Metrics  →  /m3-assurance/t3-reporting-metrics
T4 · Application Security →  /m3-assurance/t4-appsec
T5 · Red Teaming          →  /m3-assurance/t5-red-teaming
```

Match the existing format used for T1 and T2 entries.

### 7. Add Glossary Entries

The `glossary-additions.txt` file contains ~25 new term definitions. Add these to the existing glossary page, following the existing entry format.

**Check for duplicates first** — some terms like AppSec, ASM, TPRM, and XSS may already exist in the glossary. For those, compare definitions and keep whichever is more comprehensive, or merge them.

### 8. Update Footer/Source Material References

The existing footer says "Modules 1–2 · 40 Lessons + PPTX Slides". Update to reflect Module 3 content:
- "Modules 1–3 · 60+ Lessons + PPTX Slides" (approximate)

### 9. Build and Test

```bash
npm run dev
```

Verify:
- All 5 topic pages render under /m3-assurance/
- Sidebar shows all 5 topics
- Module 3 overview shows 5 topic cards  
- New glossary entries appear
- No broken links between pages
- Course number shows CS8833 throughout

---

## Content Notes

- All content is derived from Prof. Perullo's CS8833/CS6239 lecture transcripts and PPTX slides
- The writing style matches the existing site: practitioner-oriented, opinionated ("if the CISO is accepting risks on behalf of the business, the governance model is broken"), with Callout components for key takeaways
- Tag types used: `def` (definition), `fw` (framework), `tip` (practical), `new` (recent trends)
- Each lesson includes `searchData` attributes for the site's search functionality
