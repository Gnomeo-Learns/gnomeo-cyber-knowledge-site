# CS8833 Enterprise Cybersecurity Management — Module 4 (Governance) Content Package

## Overview

This package adds **Module 4: Governance** to the `gnomeo-cyber-knowledge-site` Astro site. It includes:

1. **Two new topic pages** (T1: Internal Cyber Governance, T2: External Board Cyber Governance)
2. **Module 4 overview page**
3. **New glossary entries**
4. **Sidebar navigation updates**

---

## Files in This Package

| File | Purpose | Action |
|---|---|---|
| `t1-internal-governance.astro` | Topic 1: Internal Cyber Governance (8 lessons) | Create as `src/pages/m4-governance/t1-internal-governance.astro` |
| `t2-board-governance.astro` | Topic 2: External Board Cyber Governance (6 lessons) | Create as `src/pages/m4-governance/t2-board-governance.astro` |
| `m4-overview.astro` | Module 4 overview page | Create as `src/pages/m4-governance/index.astro` |
| `glossary-m4-additions.txt` | New glossary entries for Module 4 | Add to existing glossary page |

---

## Step-by-Step Implementation

### 1. Create Module 4 Directory and Pages

```bash
mkdir -p src/pages/m4-governance/
```

Copy these files:
- `t1-internal-governance.astro` → `src/pages/m4-governance/t1-internal-governance.astro`
- `t2-board-governance.astro` → `src/pages/m4-governance/t2-board-governance.astro`
- `m4-overview.astro` → `src/pages/m4-governance/index.astro`

Verify import paths match the existing pattern (check Module 3 files for reference):
```astro
import BaseLayout from '../../layouts/BaseLayout.astro';
import LessonCard from '../../components/LessonCard.astro';
import Callout from '../../components/Callout.astro';
```

### 2. Update Sidebar Navigation

Add a new Module 4 section to the sidebar component with entries:

```
Module 04 — Governance
  T1 · Internal Governance  →  /m4-governance/t1-internal-governance
  T2 · Board Governance     →  /m4-governance/t2-board-governance
```

Match the format used for existing Module 1-3 entries.

### 3. Update Home Page

If the home page has a module card grid, add a card for Module 4:
- **Module 04 — Governance**
- Description: "Internal CyberGov committees and external board-level cybersecurity governance."
- Link: `/m4-governance`

### 4. Add Glossary Entries

Add these entries to the existing glossary page (check for duplicates first):

---

**CyberGov** — Cybersecurity Governance Committee — an internal governance committee of cross-functional senior leadership that oversees the cybersecurity program. Serves as the venue where threat objectives are validated, risk remediation is tracked, incidents are reviewed, and policy changes are ratified. Acts as a dress rehearsal for board-level reporting.

**Fiduciary** — a person required to act for the benefit of another party on all matters within the scope of their relationship. Board directors are fiduciaries with respect to shareholders, bound by duties of loyalty (no conflicts of interest) and care (exercise diligent judgment).

**NED (Non-Executive Director)** — an independent board director who is not an employee of the company and typically hasn't worked for it in the past five years. Stock exchange listing rules require a minimum number of NEDs to ensure independent oversight.

**SRO (Self-Regulatory Organization)** — an entity that creates and enforces its own rules for its members, subject to government oversight. In the U.S., the NYSE and NASDAQ are SROs that set board composition and governance rules for listed companies, with SEC oversight.

**10-K** — the mandatory annual report filed with the SEC by publicly listed companies. Includes financial statements, risk factors (where cybersecurity now features prominently), and Management Discussion & Analysis (MD&A). Key vehicle for cybersecurity risk disclosure.

**Proxy Statement** — an annual document informing shareholders about matters requiring their vote, including board director elections. Contains detailed director qualifications (now including cybersecurity expertise), board education programs, and committee composition with charter summaries.

**Risk Appetite Statement** — a formal declaration by the board defining the level of risk the organization is willing to accept. In the threat objective model, the risk appetite is visualized as a line on the heatmap — threat objectives above the line form the mission of the security program, while raising or lowering the line adjusts scope and required investment.

**Robert's Rules of Order** — a standard set of procedures for conducting formal meetings, widely used in corporate board meetings. Key elements: motions (proposals for action), seconds (another member endorsing), and votes. CISOs presenting to boards should understand this format for formal strategy approvals.

**Board Portal Software** — specialized applications installed on mobile devices that provide secure, sandboxed access to board materials. Features include MFA, encrypted local storage, and remote wipe capability. Solves the problem of distributing sensitive board decks to directors who use personal devices.

**DLP (Data Loss/Leakage Prevention)** — technology that monitors and controls data flows to prevent unauthorized transmission of sensitive information. Can be used in reverse for board communications: instead of scanning for sensitive content, require that all attachments sent to board member personal email addresses be encrypted.

---

### 5. Update Site-Wide References

Update any "Modules 1-3" references to "Modules 1-4" in headers, footers, or README files. Update lesson counts accordingly (Module 4 adds 14 lessons).

### 6. Supplementary Material — CyberGov Handbook

The source materials include a 7-page "CyberGov Handbook" PDF — a concise reference document covering key CyberGov concepts (threat objectives, risk identification, SLAs, remediation agility, incidents, compliance, controls). Consider:

- Hosting the PDF in `public/resources/` and linking to it from the Module 4 overview page as a downloadable reference
- Or summarizing its key content on a resources sub-page under Module 4

### 7. Build and Test

```bash
npm run dev
```

Verify:
- Module 4 overview page renders at /m4-governance/
- Both topic pages render with correct layouts
- Sidebar shows Module 4 with both topics
- Home page includes Module 4 card (if applicable)
- New glossary entries appear
- No broken links

---

## Content Summary

### Topic 1: Internal Cyber Governance (8 lessons)
1. Role and Form of Internal Governance
2. Sample CyberGov Charter and Agenda
3. Threats in CyberGov
4. Risks in CyberGov
5. Incidents in CyberGov
6. Compliance in CyberGov
7. Controls in CyberGov
8. Tips on Minutes and Action Items

### Topic 2: External Board Cyber Governance (6 lessons)
1. Corporate Governance 101
2. The Other IR — Investor Relations
3. The Language of the Board
4. Board Committees
5. Full Board Briefings
6. Technical Considerations in Board Communications

---

## Style Notes

- All content uses the same component patterns as Modules 1-3: `LessonCard` with `code`, `tags`, `searchData`; `Callout` variants (green/orange/purple); `section-label` divs; `bullet` lists; `lesson-refs` blocks
- Tag types used: `def` (definition), `fw` (framework), `tip` (practical), `new` (recent developments)
- Content maintains the practitioner-oriented, opinionated voice consistent with Prof. Perullo's teaching style
