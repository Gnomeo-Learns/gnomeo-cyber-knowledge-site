# CS8803 Cybersecurity Reference Site — Build Spec
**For: Claude Code**
**Owner: Joe**
**Last updated: March 2026**

---

## Overview

Build a personal cybersecurity reference website from an existing single-file HTML document. The site will host notes from Georgia Tech CS8803 / CS6239 (Enterprise Cybersecurity Management, Prof. Jerry Perullo). Content will grow over time as additional course modules are completed.

The existing HTML file (`CS8803_Reference_Guide_v2.html`) contains all current content and the complete design system. **Preserve the visual design exactly.** The goal of this build is structure and maintainability — not a redesign.

---

## Tech Stack

| Decision | Choice | Rationale |
|---|---|---|
| Framework | **Astro** | Static output, file-based routing, component model, official GitHub Pages deploy action |
| Styling | **Vanilla CSS** (no Tailwind) | Design system already exists as CSS variables in the source HTML |
| Content | **`.astro` files** | Allows HTML + frontmatter; no Markdown processor needed |
| Deployment | **GitHub Pages via GitHub Actions** | Free, HTTPS automatic, integrates with existing GitHub workflow |
| Package manager | **npm** | Standard default |

Do not introduce React, Vue, Tailwind, or any UI component library. Keep the dependency footprint minimal.

---

## Repository Setup

1. Create a new GitHub repository named `cs8803-reference` (or confirm name with Joe)
2. Initialize an Astro project in it:
   ```bash
   npm create astro@latest . -- --template empty --no-install --no-git
   npm install
   ```
3. Add the official Astro GitHub Pages deploy action (see Deployment section)
4. Enable GitHub Pages in repo Settings → Pages → Source: **GitHub Actions**
5. Set `site` and `base` in `astro.config.mjs`:
   ```js
   import { defineConfig } from 'astro/config';
   export default defineConfig({
     site: 'https://YOUR_USERNAME.github.io',
     base: '/cs8803-reference',
   });
   ```
   Update these values when a custom domain is configured (remove `base` when using a custom domain).

---

## Project Structure

```
cs8803-reference/
├── .github/
│   └── workflows/
│       └── deploy.yml              ← GitHub Actions deploy workflow
├── public/
│   └── favicon.svg                 ← Simple favicon (dark bg, lock icon or "CS" monogram)
├── src/
│   ├── layouts/
│   │   └── BaseLayout.astro        ← Shell: header, side nav, main content slot, footer
│   ├── components/
│   │   ├── SideNav.astro           ← Collapsible nav with active-page highlighting
│   │   ├── LessonCard.astro        ← Reusable lesson card (head + body + tags + refs)
│   │   ├── Callout.astro           ← Callout box component (blue/orange/green/purple variants)
│   │   ├── AcronymTooltip.astro    ← Injects the acronym tooltip script (used once in BaseLayout)
│   │   └── SearchBar.astro         ← Sticky search bar (scoped to current page)
│   ├── styles/
│   │   └── global.css              ← CSS variables, resets, shared classes
│   ├── scripts/
│   │   └── acronyms.js             ← Acronym dictionary + injection logic (extracted from v2 HTML)
│   └── pages/
│       ├── index.astro             ← Landing page / overview
│       ├── glossary.astro          ← Full glossary page
│       ├── m1-strategy/
│       │   ├── index.astro         ← Module 1 overview page
│       │   ├── t1-composition.astro
│       │   ├── t2-threat-objectives.astro
│       │   ├── t3-departmental-org.astro
│       │   ├── t4-talent-management.astro
│       │   └── t5-cti.astro
│       └── m2-operations/
│           ├── index.astro         ← Module 2 overview page
│           ├── t1-architecture.astro
│           ├── t2-cirp.astro
│           └── t3-cirp-examples.astro
├── astro.config.mjs
├── package.json
└── README.md
```

---

## Design System

Extract all of the following **exactly** from `CS8803_Reference_Guide_v2.html` into `src/styles/global.css`. Do not change any values.

### CSS Variables (copy verbatim)
```css
:root {
  --bg: #0d0f14;
  --surface: #141720;
  --surface2: #1c2130;
  --surface3: #212638;
  --border: #252c3d;
  --border2: #2e3a56;
  --accent1: #4f8ef7;   /* blue  — frameworks */
  --accent2: #f7774f;   /* orange — practical tips */
  --accent3: #4ff7b0;   /* green  — definitions */
  --accent4: #c084fc;   /* purple — new content / updates */
  --text: #d4daf0;
  --text-dim: #7a849e;
  --text-bright: #edf0ff;
  --tag-bg: #1e2540;
  --search-bg: #181c28;
}
```

### Typography (same Google Fonts import)
```
Syne (400/600/700/800) — headings, labels, lesson titles
DM Mono (300/400/500) — code labels, tags, meta, UI chrome
Lora (regular + italic, 400/500) — body text
```

### Tag / Callout Color Semantics
| Tag class | Color | Meaning |
|---|---|---|
| `.tag.def` | `--accent3` green | Definition / Key Term |
| `.tag.fw` | `--accent1` blue | Framework / Model |
| `.tag.tip` | `--accent2` orange | Practical / Career Tip |
| `.tag.new` | `--accent4` purple | 2024+ Update / New Content |
| `.callout` | blue left border | Default informational |
| `.callout.orange` | orange left border | Career/practical tip |
| `.callout.green` | green left border | Key insight |
| `.callout.purple` | purple left border | Recent update |

---

## Component Specifications

### `BaseLayout.astro`

Props: `title`, `description`, `currentPath`

Renders:
- `<head>` with Google Fonts, global.css, meta tags
- `<header>` — course label + site title (same as v2 HTML header)
- `<SearchBar />` — sticky below header
- Two-column layout: `<SideNav currentPath={currentPath} />` + `<main><slot /></main>`
- `<footer>` — same three-column footer as v2 HTML
- `<AcronymTooltip />` — injects tooltip div + script once

Side nav column: fixed width 240px, sticky, scrollable independently of main content.
Main content column: fills remaining width, max-width 860px, padding 0 2rem.

### `SideNav.astro`

Hardcoded nav structure (update manually when new modules are added — see `nav-structure.json` for the initial structure).

Behavior:
- Module sections are collapsible (click module label to expand/collapse)
- Current page is highlighted with `--accent1` color and a left border indicator
- Active module section is always expanded on load; others collapsed by default
- On mobile (< 768px): nav collapses to a hamburger menu at the top

Nav link format:
```
MODULE 01 — STRATEGY          ← section label (collapsible)
  T1 · Strategy Composition   ← page link
  T2 · Threat Objectives
  ...
MODULE 02 — OPERATIONS
  ...
REFERENCE
  Glossary
```

### `LessonCard.astro`

Props: `code` (e.g. "M1T1L2"), `title`, `tags[]`

Slot: lesson body content (paragraphs, callouts, bullet lists, refs)

Renders the `.lesson` card structure from v2 HTML:
- `.lesson-head` with code + title
- `.lesson-body` with tags row + slotted content

### `Callout.astro`

Props: `variant` ("default" | "orange" | "green" | "purple")

Slot: callout text content

### `AcronymTooltip.astro`

Renders the `#acro-tooltip` div and injects the full acronym injection script from `src/scripts/acronyms.js` via a `<script>` tag. Include this once in BaseLayout.

### `SearchBar.astro`

Sticky search input that filters `.lesson` cards on the current page only (same logic as v2 HTML). Shows match count. Clears on button click.

---

## Content Migration

Migrate all content from `CS8803_Reference_Guide_v2.html` into the page files. Preserve all text, callouts, bullet points, reference links, and lesson codes exactly.

### Page → File Mapping

| Source section in v2 HTML | Target file |
|---|---|
| Header + TOC + Legend | `src/pages/index.astro` (landing page) |
| Module 1 intro | `src/pages/m1-strategy/index.astro` |
| T1: Strategy Composition (L1–L3) | `src/pages/m1-strategy/t1-composition.astro` |
| T2: Threat Objectives (L1–L6) | `src/pages/m1-strategy/t2-threat-objectives.astro` |
| T3: Departmental Organization (L1–L6) | `src/pages/m1-strategy/t3-departmental-org.astro` |
| T4: Talent Management (L1–L5) | `src/pages/m1-strategy/t4-talent-management.astro` |
| T5: Cyber Threat Intelligence (L1–L5) | `src/pages/m1-strategy/t5-cti.astro` |
| Module 2 intro | `src/pages/m2-operations/index.astro` |
| T1: Architecture and Automation (L1–L8) | `src/pages/m2-operations/t1-architecture.astro` |
| T2: CIRP (L1–L6) | `src/pages/m2-operations/t2-cirp.astro` |
| T3: CIRP Examples (9 incidents) | `src/pages/m2-operations/t3-cirp-examples.astro` |
| Glossary grid | `src/pages/glossary.astro` |

### Landing Page (`index.astro`)

The landing page should include:
- The legend bar (tag color key + acronym tooltip explanation)
- A module/topic overview grid (links to all module index pages)
- A brief description of the site and course
- No lesson cards — those live on topic pages

### Module Index Pages (`m1-strategy/index.astro`, etc.)

Each module index should include:
- Module title + brief description
- A card-style link grid to each topic page within that module
- Do not duplicate lesson content here

---

## GitHub Actions Deploy Workflow

Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [main]
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

concurrency:
  group: pages
  cancel-in-progress: false

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Setup Node
        uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: npm
      - name: Install dependencies
        run: npm ci
      - name: Build Astro
        run: npm run build
      - name: Upload artifact
        uses: actions/upload-pages-artifact@v3
        with:
          path: ./dist

  deploy:
    needs: build
    runs-on: ubuntu-latest
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    steps:
      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v4
```

---

## Custom Domain (future step — do not configure yet)

When Joe is ready to add a custom domain:
1. Add a `CNAME` file to `public/` with the domain (e.g., `joesec.dev`)
2. Remove the `base` option from `astro.config.mjs`
3. Update `site` to the custom domain URL
4. Configure DNS at Cloudflare: CNAME `www` → `YOUR_USERNAME.github.io`, and A records for apex domain per GitHub's IP list

---

## README.md

Generate a clear README covering:
- What the site is
- Local development (`npm run dev`)
- How to add a new module/topic page (step-by-step)
- How to update the nav structure
- Deploy process (automatic on push to main)
- Future: custom domain instructions

---

## Workflow for Future Content Updates

When Joe adds new module content, the process will be:

1. **Joe generates new content** in Claude.ai → receives a new `.astro` page file
2. **Claude Code's job**: 
   - Add the new file to the correct `pages/` subdirectory
   - Add the new topic to `SideNav.astro` nav structure
   - Add a link card to the module index page
   - Commit with a descriptive message (e.g., `"Add M3T1: Security Assurance - AppSec"`)
   - Push to main → GitHub Actions deploys automatically

Joe will provide the `.astro` file content. Claude Code does not need to generate course content — only integrate it.

---

## Acronym System

Extract the full `ACRONYMS` dictionary object and the `injectAcronymTooltips()` function from `CS8803_Reference_Guide_v2.html` into `src/scripts/acronyms.js`. Export both.

The `AcronymTooltip.astro` component should:
1. Render the `#acro-tooltip` div (same HTML as in v2)
2. Import and inline the script via `<script>` tag so it runs on every page

The injection function must run after DOM load on every page. Since Astro does client-side navigation for same-site links (if `@astrojs/prefetch` is added), consider re-running injection on navigation if that integration is added later. For now, `DOMContentLoaded` is sufficient.

---

## Acceptance Criteria

Before handing back to Joe, verify:

- [ ] `npm run dev` starts without errors
- [ ] `npm run build` completes without errors
- [ ] All pages render with the correct dark theme, fonts, and color system
- [ ] Side nav appears on all pages; current page is highlighted
- [ ] Collapsible nav sections work correctly
- [ ] Acronym tooltips work on at least one content page
- [ ] Search filters lesson cards on topic pages
- [ ] All lesson content from v2 HTML is present in the correct page files
- [ ] Glossary page renders the full glossary grid
- [ ] GitHub Actions workflow file is present and syntactically valid
- [ ] `README.md` includes local dev and content update instructions
- [ ] No console errors on page load
- [ ] Mobile layout is reasonable (nav accessible, content readable)

---

## Files Joe Will Provide

- `CS8803_Reference_Guide_v2.html` — source of all current content and the complete design system. Treat this as the single source of truth.
- `nav-structure.json` — initial nav structure (provided alongside this spec)
- Additional `.astro` content pages as new modules are completed (future)
